package com.example.instagramclone;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.LogInCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

public class LogIn extends AppCompatActivity implements TextWatcher, View.OnClickListener {

    private EditText mLogInEmailNameTxt, mLogInPassWordTxt;
    private Button mLogInBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        mLogInEmailNameTxt = findViewById(R.id.logInEmailEditTxt);
        mLogInPassWordTxt = findViewById(R.id.logInPassWordEditTxt);
        mLogInBtn = findViewById(R.id.logInButton);
        mLogInBtn.setOnClickListener(this);

        mLogInEmailNameTxt.addTextChangedListener(this);
        mLogInPassWordTxt.addTextChangedListener(this);

        if(ParseUser.getCurrentUser() != null) {
            ParseUser.getCurrentUser().logOut();
        }
    }

    @Override
    public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

    }

    @Override
    public void afterTextChanged(Editable editable) {
        if(!(mLogInEmailNameTxt.getText().toString().trim().isEmpty()
                || mLogInPassWordTxt.getText().toString().trim().isEmpty())) {
            mLogInBtn.setEnabled(true);
            mLogInBtn.animate().alpha(1);
        } else if(mLogInBtn.isEnabled()){
            mLogInBtn.setEnabled(false);
            mLogInBtn.animate().alpha(0.5f);
        }
    }

    @Override
    public void onClick(View view) {

        switch(view.getId()) {
            case R.id.logInButton:
                final ParseUser user = new ParseUser();

                user.logInInBackground(mLogInEmailNameTxt.getText().toString(),
                        mLogInPassWordTxt.getText().toString(),
                        new LogInCallback() {
                            @Override
                            public void done(ParseUser user, ParseException e) {
                                if(user != null && e == null) {
                                    Toast.makeText(LogIn.this, "usuario logado", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(LogIn.this, e.getMessage() + "", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                break;
        }

    }
}
